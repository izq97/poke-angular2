# Pokedex
Este proyecto fue generado con Angular CLI versión 15.0.4.

# Servidor de desarrollo
Ejecute ng serve para iniciar el servidor de desarrollo. Navegue a http://localhost:4200/. La aplicación se recargará automáticamente si cambia alguno de los archivos de origen.

# Generación de código
Ejecute ng generate component nombre-componente para generar un nuevo componente. También puede usar ng generate directive|pipe|service|class|guard|interface|enum|module.

# Ejecución de pruebas unitarias
Ejecute ng test para ejecutar las pruebas unitarias a través de Karma.

# Ayuda adicional
Para obtener más ayuda sobre Angular CLI, use ng help o consulte la página Angular CLI Overview and Command Reference.